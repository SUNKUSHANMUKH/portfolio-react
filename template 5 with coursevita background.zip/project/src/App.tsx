import { Portfolio } from './components/Portfolio';
import './index.css';

function App() {
  return <Portfolio />;
}

export default App;