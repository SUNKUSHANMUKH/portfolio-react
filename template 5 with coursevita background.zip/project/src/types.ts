export interface SocialMedia {
  type: string;
  url: string;
}

export interface Experience {
  title: string;
  company: string;
  period: string;
  location: string;
  description: string[];
  technologies: string[];
}

export interface Project {
  title: string;
  description: string;
  image: string;
  technologies: string[];
  liveUrl?: string;
  githubUrl?: string;
}

export interface UserData {
  first_name: string;
  last_name: string;
  description: string;
  profile_picture: string;
  social_media?: SocialMedia[];
  experience: Experience[];
  projects: Project[];
  contact: {
    email: string;
    phone: string;
    location: string;
  };
}