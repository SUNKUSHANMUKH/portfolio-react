import React, { useState, useEffect } from 'react';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import {
  Github, Linkedin, Instagram, Twitter, Mail, MapPin,
  ExternalLink, Download, Trophy, Phone, Menu, X,
  MousePointer2, ArrowRight, Briefcase, Building,
  Calendar, GraduationCap
} from 'lucide-react';
import { userData } from '../data';

export const Portfolio = () => {
  const [activeSection, setActiveSection] = useState('home');
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isNavOpen, setIsNavOpen] = useState(false);
  const [cursorText, setCursorText] = useState('');

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      { threshold: 0.5 }
    );

    document.querySelectorAll('section[id]').forEach((section) => {
      observer.observe(section);
    });

    return () => observer.disconnect();
  }, []);

  const navItems = [
    { name: 'Home', icon: '🏠' },
    { name: 'About', icon: '👤' },
    { name: 'Experience', icon: '💼' },
    { name: 'Projects', icon: '🚀' },
    { name: 'Contact', icon: '📧' },
  ];

  const { scrollY } = useScroll();
  const navBackground = useTransform(
    scrollY,
    [0, 100],
    ['rgba(255, 255, 255, 0)', 'rgba(255, 255, 255, 0.9)']
  );

  return (
    <div className="min-h-screen relative" style={{ background: 'linear-gradient(to right, #673AB7, #E91E63)' }}>
      {/* Custom Cursor */}
      <motion.div
        className="fixed w-4 h-4 bg-orange-500 rounded-full pointer-events-none z-50 mix-blend-difference"
        animate={{ x: mousePosition.x - 8, y: mousePosition.y - 8 }}
        transition={{ type: 'spring', stiffness: 500, damping: 28 }}
      />
      <motion.div
        className="fixed text-sm text-white pointer-events-none z-50 transform -translate-x-1/2 -translate-y-1/2"
        animate={{ x: mousePosition.x, y: mousePosition.y }}
        transition={{ type: 'spring', stiffness: 500, damping: 28 }}
      >
        {cursorText}
      </motion.div>

      {/* Navigation */}
      <motion.nav
        style={{ backgroundColor: navBackground }}
        className="fixed top-0 left-0 right-0 z-50 backdrop-blur-sm"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-2xl font-bold text-white"
            >
              {userData.first_name}
              <span className="text-pink-300">.</span>
            </motion.div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-1">
              {navItems.map((item) => (
                <motion.button
                  key={item.name}
                  onClick={() => {
                    document
                      .getElementById(item.name.toLowerCase())
                      ?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  onHoverStart={() => setCursorText(item.name)}
                  onHoverEnd={() => setCursorText('')}
                  className={`relative px-4 py-2 rounded-full transition-all duration-300 text-white hover:text-pink-200`}
                >
                  <span className="relative z-10 flex items-center gap-2">
                    <span className="text-lg">{item.icon}</span>
                    {item.name}
                  </span>
                  {activeSection === item.name.toLowerCase() && (
                    <motion.div
                      layoutId="navbar-pill"
                      className="absolute inset-0 bg-white/10 rounded-full -z-10"
                      transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                </motion.button>
              ))}
            </div>

            {/* Mobile Navigation Button */}
            <motion.button
              className="md:hidden w-12 h-12 flex items-center justify-center rounded-full bg-white/10 text-white"
              onClick={() => setIsNavOpen(!isNavOpen)}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              {isNavOpen ? <X /> : <Menu />}
            </motion.button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        <AnimatePresence>
          {isNavOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="md:hidden absolute top-full left-0 right-0 bg-white/10 backdrop-blur-md border-t border-white/20"
            >
              <div className="p-4 space-y-2">
                {navItems.map((item) => (
                  <motion.button
                    key={item.name}
                    onClick={() => {
                      document
                        .getElementById(item.name.toLowerCase())
                        ?.scrollIntoView({ behavior: 'smooth' });
                      setIsNavOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all text-white
                      ${activeSection === item.name.toLowerCase()
                        ? 'bg-white/20'
                        : 'hover:bg-white/10'
                      }`}
                    whileHover={{ x: 10 }}
                  >
                    <span className="text-xl">{item.icon}</span>
                    {item.name}
                    <ArrowRight className="ml-auto h-4 w-4" />
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.nav>

      {/* Hero Section */}
      <section id="home" className="min-h-screen pt-32 pb-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="relative"
            >
              {/* Decorative Elements */}
              <motion.div
                className="absolute -top-20 -left-20 w-40 h-40 bg-pink-200 rounded-full mix-blend-multiply filter blur-xl opacity-70"
                animate={{
                  scale: [1, 1.2, 1],
                  rotate: [0, 90, 0],
                }}
                transition={{
                  duration: 8,
                  repeat: Infinity,
                  repeatType: 'reverse',
                }}
              />
              <motion.div
                className="absolute -bottom-20 -right-20 w-40 h-40 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-70"
                animate={{
                  scale: [1, 1.2, 1],
                  rotate: [0, -90, 0],
                }}
                transition={{
                  duration: 8,
                  repeat: Infinity,
                  repeatType: 'reverse',
                }}
              />

              <h1 className="text-6xl font-bold leading-tight mb-6">
                Hi, I'm{' '}
                <span className="text-pink-300">
                  {userData.first_name}
                </span>
                <br />
                <motion.span
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  {userData.last_name}
                </motion.span>
              </h1>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-xl mb-8 leading-relaxed"
              >
                {userData.description}
              </motion.p>

              <div className="flex gap-4 mb-8">
                {userData.social_media?.map((social, index) => {
                  const icons: { [key: string]: React.FC } = {
                    github: Github,
                    linkedin: Linkedin,
                    twitter: Twitter,
                    instagram: Instagram,
                  };
                  const Icon = icons[social.type];
                  return Icon ? (
                    <motion.a
                      key={index}
                      href={social.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-3 bg-white/10 rounded-xl text-white hover:bg-white/20 transition-all"
                      whileHover={{ y: -5 }}
                      onHoverStart={() => setCursorText('Connect')}
                      onHoverEnd={() => setCursorText('')}
                    >
                      <Icon />
                    </motion.a>
                  ) : null;
                })}
              </div>

              <motion.button
                className="group flex items-center gap-2 px-6 py-3 bg-white/10 text-white rounded-full hover:bg-white/20 transition-all"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onHoverStart={() => setCursorText('Download')}
                onHoverEnd={() => setCursorText('')}
              >
                <Download size={20} />
                <span>Download Resume</span>
                <motion.span
                  className="opacity-0 group-hover:opacity-100 transition-opacity"
                  initial={{ x: -10 }}
                  animate={{ x: 0 }}
                >
                  →
                </motion.span>
              </motion.button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
              className="relative"
            >
              <div className="relative aspect-square rounded-3xl bg-gradient-to-br from-pink-300/20 to-purple-300/20 overflow-hidden shadow-2xl">
                <img
                  src={userData.profile_picture}
                  alt={`${userData.first_name} ${userData.last_name}`}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
              </div>

              {/* Floating badges */}
              <motion.div
                className="absolute -top-6 -right-6 bg-white/10 p-4 rounded-2xl backdrop-blur-md"
                animate={{
                  y: [0, -10, 0],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                }}
              >
                <Trophy className="h-6 w-6 text-pink-300" />
              </motion.div>

              <motion.div
                className="absolute -bottom-6 -left-6 bg-white/10 p-4 rounded-2xl backdrop-blur-md"
                animate={{
                  y: [0, 10, 0],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: 1,
                }}
              >
                <MousePointer2 className="h-6 w-6 text-pink-300" />
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      <section id="about" className="min-h-screen py-20 bg-white/5 backdrop-blur-lg text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-8">About Me</h2>
            <p className="text-xl leading-relaxed">
              I'm a passionate developer with expertise in building modern web
              applications. My journey in software development started 5 years
              ago, and since then, I've worked with various technologies and
              frameworks to create efficient and scalable solutions.
            </p>
          </motion.div>
        </div>
      </section>

      <section id="experience" className="min-h-screen py-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-12">Experience</h2>
            <div className="space-y-12">
              {userData.experience.map((exp, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true }}
                  className="relative"
                >
                  {/* Timeline line */}
                  {index !== userData.experience.length - 1 && (
                    <div className="absolute left-8 top-16 bottom-0 w-px bg-white/20" />
                  )}

                  <div className="flex gap-8">
                    <div className="flex-shrink-0 w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center">
                      <Briefcase className="w-8 h-8 text-pink-300" />
                    </div>
                    <div className="flex-grow">
                      <h3 className="text-2xl font-bold">
                        {exp.title}
                      </h3>
                      <div className="flex flex-wrap gap-4 mt-2">
                        <div className="flex items-center gap-1">
                          <Building className="w-4 h-4" />
                          <span>{exp.company}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          <span>{exp.period}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          <span>{exp.location}</span>
                        </div>
                      </div>
                      <ul className="mt-4 space-y-2">
                        {exp.description.map((desc, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="flex-shrink-0 w-1.5 h-1.5 mt-2 rounded-full bg-pink-300" />
                            <span>{desc}</span>
                          </li>
                        ))}
                      </ul>
                      <div className="mt-4 flex flex-wrap gap-2">
                        {exp.technologies.map((tech, i) => (
                          <span
                            key={i}
                            className="px-3 py-1 text-sm bg-white/10 rounded-full"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      <section id="projects" className="min-h-screen py-20 bg-white/5 backdrop-blur-lg text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-12">Featured Projects</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {userData.projects.map((project, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true }}
                  className="group relative bg-white/10 rounded-2xl overflow-hidden backdrop-blur-md"
                >
                  {/* Project Image */}
                  <div className="relative h-48 overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/50 z-10" />
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-300"
                    />
                  </div>

                  {/* Project Content */}
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                    <p className="mb-4">{project.description}</p>

                    {/* Technologies */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.technologies.map((tech, i) => (
                        <span
                          key={i}
                          className="px-3 py-1 text-sm bg-white/10 rounded-full"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>

                    {/* Links */}
                    <div className="flex gap-4">
                      {project.liveUrl && (
                        <motion.a
                          href={project.liveUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 text-pink-300 hover:text-pink-200"
                          whileHover={{ x: 5 }}
                        >
                          <ExternalLink className="w-4 h-4" />
                          <span>Live Demo</span>
                        </motion.a>
                      )}
                      {project.githubUrl && (
                        <motion.a
                          href={project.githubUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 hover:text-pink-200"
                          whileHover={{ x: 5 }}
                        >
                          <Github className="w-4 h-4" />
                          <span>Source Code</span>
                        </motion.a>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      <section id="contact" className="min-h-screen py-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="grid md:grid-cols-2 gap-12"
          >
            {/* Contact Information */}
            <div>
              <h2 className="text-4xl font-bold mb-8">Get in Touch</h2>
              <p className="text-xl mb-8">
                I'm always open to new opportunities and interesting projects.
                Feel free to reach out!
              </p>

              <div className="space-y-6">
                <motion.a
                  href={`mailto:${userData.contact.email}`}
                  className="flex items-center gap-4 p-4 bg-white/10 rounded-xl backdrop-blur-md hover:bg-white/20 transition-all"
                  whileHover={{ x: 10 }}
                >
                  <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center">
                    <Mail className="w-6 h-6 text-pink-300" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Email</h3>
                    <p>{userData.contact.email}</p>
                  </div>
                </motion.a>

                <motion.div
                  className="flex items-center gap-4 p-4 bg-white/10 rounded-xl backdrop-blur-md"
                  whileHover={{ x: 10 }}
                >
                  <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center">
                    <Phone className="w-6 h-6 text-pink-300" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Phone</h3>
                    <p>{userData.contact.phone}</p>
                  </div>
                </motion.div>

                <motion.div
                  className="flex items-center gap-4 p-4 bg-white/10 rounded-xl backdrop-blur-md"
                  whileHover={{ x: 10 }}
                >
                  <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center">
                    <MapPin className="w-6 h-6 text-pink-300" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Location</h3>
                    <p>{userData.contact.location}</p>
                  </div>
                </motion.div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-white/10 p-8 rounded-2xl backdrop-blur-md">
              <h3 className="text-2xl font-bold mb-6">Send a Message</h3>
              <form className="space-y-6">
                <div>
                  <label
                    htmlFor="name"
                    className="block text-sm font-medium mb-2"
                  >
                    Your Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:ring-2 focus:ring-pink-300 focus:border-transparent"
                    placeholder="John Doe"
                  />
                </div>
                <div>
                  <label
                    htmlFor="email"
                    className="block text-sm font-medium mb-2"
                  >
                    Your Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:ring-2 focus:ring-pink-300 focus:border-transparent"
                    placeholder="john@example.com"
                  />
                </div>
                <div>
                  <label
                    htmlFor="message"
                    className="block text-sm font-medium mb-2"
                  >
                    Message
                  </label>
                  <textarea
                    id="message"
                    rows={4}
                    className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:ring-2 focus:ring-pink-300 focus:border-transparent"
                    placeholder="Your message here..."
                  />
                </div>
                <motion.button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-white/10 rounded-lg hover:bg-white/20 transition-colors"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Mail className="w-5 h-5" />
                  <span>Send Message</span>
                </motion.button>
              </form>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Portfolio;