import { UserData } from './types';

export const userData: UserData = {
  first_name: 'John',
  last_name: 'Doe',
  description: 'A passionate full-stack developer with a love for creating beautiful and functional web applications.',
  profile_picture: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=800&q=80',
  social_media: [
    { type: 'github', url: 'https://github.com' },
    { type: 'linkedin', url: 'https://linkedin.com' },
    { type: 'twitter', url: 'https://twitter.com' },
    { type: 'instagram', url: 'https://instagram.com' },
  ],
  experience: [
    {
      title: 'Senior Full Stack Developer',
      company: 'Tech Innovations Inc',
      period: '2021 - Present',
      location: 'San Francisco, CA',
      description: [
        'Led a team of 5 developers in building a cloud-based SaaS platform',
        'Improved system performance by 40% through optimization',
        'Implemented CI/CD pipeline reducing deployment time by 60%',
      ],
      technologies: ['React', 'Node.js', 'TypeScript', 'AWS', 'Docker'],
    },
    {
      title: 'Full Stack Developer',
      company: 'Digital Solutions Ltd',
      period: '2019 - 2021',
      location: 'New York, NY',
      description: [
        'Developed and maintained multiple client-facing applications',
        'Integrated third-party APIs and payment gateways',
        'Mentored junior developers and conducted code reviews',
      ],
      technologies: ['Vue.js', 'Python', 'Django', 'PostgreSQL'],
    },
    {
      title: 'Frontend Developer',
      company: 'WebCraft Studios',
      period: '2017 - 2019',
      location: 'Boston, MA',
      description: [
        'Built responsive web applications using modern JavaScript frameworks',
        'Collaborated with designers to implement pixel-perfect UIs',
        'Reduced load time by 50% through optimization techniques',
      ],
      technologies: ['JavaScript', 'React', 'SASS', 'Webpack'],
    },
  ],
  projects: [
    {
      title: 'E-Commerce Platform',
      description: 'A full-stack e-commerce platform with real-time inventory management, payment processing, and admin dashboard.',
      image: 'https://images.unsplash.com/photo-1557821552-17105176677c?auto=format&fit=crop&w=1600&q=80',
      technologies: ['Next.js', 'TypeScript', 'Stripe', 'Tailwind CSS'],
      liveUrl: 'https://example.com',
      githubUrl: 'https://github.com',
    },
    {
      title: 'AI Task Manager',
      description: 'Smart task management app with AI-powered prioritization and time estimation features.',
      image: 'https://images.unsplash.com/photo-1661961112835-ca6f5811d2af?auto=format&fit=crop&w=1600&q=80',
      technologies: ['React', 'Python', 'TensorFlow', 'FastAPI'],
      liveUrl: 'https://example.com',
      githubUrl: 'https://github.com',
    },
    {
      title: 'Social Media Analytics',
      description: 'Real-time social media analytics dashboard with sentiment analysis and trend prediction.',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1600&q=80',
      technologies: ['Vue.js', 'Node.js', 'D3.js', 'MongoDB'],
      liveUrl: 'https://example.com',
      githubUrl: 'https://github.com',
    },
  ],
  contact: {
    email: 'john.doe@example.com',
    phone: '+1 (555) 123-4567',
    location: 'San Francisco, CA',
  },
};